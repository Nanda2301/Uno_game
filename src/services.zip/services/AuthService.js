const {findUserByEmail} = require("./UserService")
const TokenBlacklist = require("../models/TokenBlacklist");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const Result = require("../config/result")


class AuthService {
  async login(email, password) {
    const result = await findUserByEmail(email);
    if(!result.ok) return result

    const user = result.value

    const senhaValida = await bcrypt.compare(password, user.password);
    if (!senhaValida) return Result.fail(new Error("Senha inválida"), 401)

    const secret = process.env.JWT_SECRET || "fallback_secret_dev";
    const token = jwt.sign(
      { id: user.id, email: user.email },
      secret,
      { expiresIn: "1h" }
    );

    return Result.of(token)
  }

  async logout(token) {
    await TokenBlacklist.create({ token });
    return { message: "Logout realizado com sucesso" };
  }
}

module.exports = new AuthService();
